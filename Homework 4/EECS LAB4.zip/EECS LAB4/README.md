README - Shangjie Ma
2019-10-30 
#This program is written by C++/Cilk PLUS FOR EECS245
#Compiler Info: GCC (Ubuntu 6.2.0-5ubuntu12) 6.2.0 20161005 

To compile 'nQueens_cilkplus.cpp', use:
*g++ -std=c++0x nQueens_cilkplus.cpp -fcilkplus -o nQueens_cilkplus*

To run:
./nQueens_cilkplus.

The following is the example result:

**This program is to show number of solutions of N-Queens Problem
The chessboard will be NxN.Please enter the number of Queens(N)**
*8*
One solution is given by:
10000000
00001000
00000001
00000100
00100000
00000010
01000000
00010000
8 Queens Problem. Nice!
The number of solution is :92
CPU CLOCK TIME is 0.002463 seconds

