Problem 1 is compiled in Visual Studio 2019
Two cpp files are attached and ready to compile.
Two executive files in windows platform are attached for demo.

Problem 2 is compiled on MacOS
